export function getRandomIntegerBelow(num) {
    return Math.floor(Math.random() * num);
}
