export const clientRequiredFields = { isActive: true };
