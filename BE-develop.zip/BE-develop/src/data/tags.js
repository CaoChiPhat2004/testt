export const tags = [
    { name: 'Áo khoác' },
    { name: 'Áo len' },
    { name: 'Áo phông' },
    { name: 'Áo sơ mi' },
    { name: 'Quần dài' },
    { name: 'Quần đùi' },
];
