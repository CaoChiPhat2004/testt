export const categories = [{ name: 'Nam' }, { name: 'Nữ' }, { name: 'Trẻ em' }, { name: 'Unisex' }];
