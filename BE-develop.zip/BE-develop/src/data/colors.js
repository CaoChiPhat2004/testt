export const colors = [
    { hex: '#FF5733', name: 'Red' },
    { hex: '#33FF57', name: 'Green' },
    { hex: '#3357FF', name: 'Blue' },
    { hex: '#FFFF33', name: 'Yellow' },
    { hex: '#FF33FF', name: 'Magenta' },
    { hex: '#33FFFF', name: 'Cyan' },
    { hex: '#000000', name: 'Black' },
    { hex: '#FFFFFF', name: 'White' },
];
