export const ROLE = {
    USER: 'user',
    SYSTEM: 'system',
    ADMIN: 'admin',
};
