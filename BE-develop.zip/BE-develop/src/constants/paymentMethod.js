export const PAYMENT_METHOD = {
    CASH: 'cash',
    CARD: 'card',
};
