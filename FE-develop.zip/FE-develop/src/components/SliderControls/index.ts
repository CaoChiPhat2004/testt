export { default } from './SliderControls';
