import DeliveryIcon from './DeliveryIcon';
import HandIcon from './HandIcon';
import HelpCenterIcon from './HelpCenterIcon';
import PaymentIcon from './PaymentIcon';

export { DeliveryIcon, HandIcon, HelpCenterIcon, PaymentIcon };
