export const orderSelectTypes = [
    {
        label: 'Order code',
        value: 'orderCode',
    },
    {
        label: 'Customer name',
        value: 'customerName',
    },
];
