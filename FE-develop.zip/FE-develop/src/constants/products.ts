export const MIN_PRICE = 0;
export const MAX_PRICE = 15599990;
