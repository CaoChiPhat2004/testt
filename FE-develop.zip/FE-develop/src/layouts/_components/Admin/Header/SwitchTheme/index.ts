export { default } from './SwitchTheme';
