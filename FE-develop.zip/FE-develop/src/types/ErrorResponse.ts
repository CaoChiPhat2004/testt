export interface errorResponse {
    response: {
        data: {
            message: string;
        };
    };
}
