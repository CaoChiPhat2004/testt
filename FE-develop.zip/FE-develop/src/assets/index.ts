import userImageDf from './img/anhdd.png';
// import logo from './img/logo.png';
import frameUser from './img/frameUser.png';

const StaticImages = {
    userImageDf,
    // logo,
    frameUser,
};

export default StaticImages;
