export { default } from './ColorList';
