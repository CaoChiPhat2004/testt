import { Pagination, Rate, Spin } from 'antd';
import { useCallback, useEffect, useRef } from 'react';
import { useDispatch } from 'react-redux';
import { useParams } from 'react-router-dom';
import useFilter from '~/hooks/common/useFilter';
import { setScroll } from '~/store/slice/autoScrollTopSlice';
import { useTypedSelector } from '~/store/store';
import { Params } from '~/types/Api';
import ReviewItem from './ReviewItem';
import ReviewStars from './ReviewStars';

const ProductReviews = ({
    reviewStarData,
    reviewData,
    isLoading,
}: {
    reviewStarData: any;
    reviewData: any;
    isLoading: boolean;
}) => {
    const { id } = useParams();
    const { reset, query, updateQueryParam } = useFilter();
    const myRef = useRef<HTMLDivElement>(null);
    const dispatch = useDispatch();
    const autoScroll = useTypedSelector((state) => state.autoScrollSlice);

    const handleUpdateQueryParams = useCallback(
        (queryParams: Params) => {
            updateQueryParam(queryParams);
            const rect = myRef.current?.getBoundingClientRect();
            dispatch(setScroll({ scroll: 'manual', location: ((rect?.top as number) + 320) as number }));
        },
        [myRef.current, autoScroll]
    );

    useEffect(() => {
        return () => {
            dispatch(setScroll({ scroll: 'auto', location: 0 }));
        };
    }, []);
    return (
        <div className='mt-20 border-t border-black/40 bg-white'>
            <h4 className='mt-10 mb-6 text-2xl font-medium'>Đánh giá sản phẩm</h4>
            <div>
                <div className='flex justify-between gap-16 rounded-sm border border-gray-100 bg-gray-50 p-8'>
                    <div className='basis-[25%]'>
                        <div className='text-lg'>
                            <span className='text-2xl font-bold'>{reviewStarData?.data.everage || 0}</span> trên 5
                        </div>
                        <div className='mt-2'>
                            <Rate
                                allowHalf
                                disabled
                                defaultValue={reviewStarData?.data.everage || 0}
                                value={reviewStarData?.data.everage}
                                style={{
                                    fontSize: 18,
                                }}
                            />
                        </div>
                    </div>
                    <div className='flex basis-[70%] flex-wrap gap-3'>
                        {reviewStarData && (
                            <ReviewStars
                                reviews={reviewStarData.data.reviewsStar}
                                handleUpdateQueryParams={handleUpdateQueryParams}
                                reset={reset}
                                query={query}
                            />
                        )}
                    </div>
                </div>
                <div className='relative mt-5' ref={myRef}>
                    <div className='p-4'>
                        {reviewData &&
                            reviewData.data?.data?.map((item: any) => <ReviewItem key={item._id} item={item} />)}
                    </div>
                    {isLoading && (
                        <div className='absolute inset-1/2 -translate-x-1/2 -translate-y-1/2 transform'>
                            <Spin />
                        </div>
                    )}

                    {reviewData && reviewData?.data.data.length > 0 && (
                        <div className='my-3'>
                            <Pagination
                                align='center'
                                onChange={(page) => {
                                    updateQueryParam({ ...query, page: page });
                                }}
                                pageSize={5}
                                defaultCurrent={Number(query.page) || 1}
                                current={Number(query.page) || 1}
                                total={reviewData?.totalDocs as number}
                            />
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};

export default ProductReviews;
