export { default } from './WishList';
